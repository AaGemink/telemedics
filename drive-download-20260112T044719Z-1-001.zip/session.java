package aplikasi;

public class session {
    public static int idUser;
    public static String role;
    public static String nama;
    public static String username;
}


    
    

